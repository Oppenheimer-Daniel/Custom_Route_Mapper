// wait for the log to print in order to press start
// This is my Route mapper app. Once you click start a timer starts counting and a line will be drawn tracking your movement. It will automatically track so you never have to press any buttons while traveling. 
// The app records the amount of time passed and the distance you traveled. Once you end the route it will display your average mile time pace based on the time spent on the route and the distance traveled.
// The only issue is that if you have poor internet and click the start button too soon it will not work. This only happens for the first attempt however. If you choose the restart this will not happen.
// Once the route ends a restart button will appear which will restart the route, the timer, and the polyline as well as the distance traveled.

import React, { useState, useEffect, useRef } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, Image } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import { Pedometer } from 'expo-sensors';

const calculateDistance = (coord1, coord2) => {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (coord2.latitude - coord1.latitude) * (Math.PI / 180);
  const dLon = (coord2.longitude - coord1.longitude) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(coord1.latitude * (Math.PI / 180)) *
      Math.cos(coord2.latitude * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in kilometers
  return distance * 3280.84; // Convert to feet
};

export default function App() {
  const [coordinate, setCoord] = useState({ latitude: 0, longitude: 0 });
  const [coordinate2, setCoord2] = useState([]);
  const [bool, setBool] = useState(false);
  const [list, setList] = useState([]);
  const [count, setCount] = useState(0);
  const [start, setStart] = useState(false);
  const [stepCount, setStepCount] = useState(0);
  const [distanceTraveled, setDistanceTraveled] = useState(0);
  const [endRoute, setEndRoute] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0); // New state for elapsed time
  const intervalRef = useRef(null);

  const add = () => {
    const newCoordinate = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    };
    setList([...list, newCoordinate]);
  };

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      if (start && !endRoute) {
        setElapsedTime((prevTime) => prevTime + 1);
      }
    }, 1000);

    return () => clearInterval(intervalRef.current);
  }, [start, endRoute]);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      console.log(location);
      setCoord(location.coords);
      setCoord2(location.coords);
    })();
  }, []);

  useEffect(() => {
    if (list.length > 1 && !endRoute) {
      const lastTwoCoords = [list[list.length - 2], list[list.length - 1]];
      const distance = calculateDistance(lastTwoCoords[0], lastTwoCoords[1]);
      setDistanceTraveled((prevDistance) => prevDistance + distance);
    }
  }, [list, endRoute]);

  const startMethod = () => {
    //console.log(coordinate2);
    if (coordinate2 != []) {
      setStart(true);
      setStartTime(new Date());
    }
  };

  const endRouteMethod = () => {
    setEndRoute(true);
    setEndTime(new Date());
  };

  const calculateAvgMileTime = () => {
    // convert m to m/s then convert m/s to mph then convert mph to avg mile time

    if (startTime && endTime && distanceTraveled > 0) {
      const timeDifference = endTime.getTime() - startTime.getTime(); // in milliseconds
      const timeInSeconds = timeDifference / 1000; // in seconds
      const timeInMinutes = timeInSeconds / 60; // in minutes
      const avgPacePerMile = timeInMinutes / (distanceTraveled * 0.000189394); // in minutes per mile
      return avgPacePerMile.toFixed(0);
    }
    return null;
  };

  const restart = () => {
    setCoord({ latitude: 0, longitude: 0 });
    setCoord2({ latitude: 0, longitude: 0 }); // Reset coordinate2 to initial location
    setBool(false);
    setList([]);
    setCount(0);
    setStart(false);
    setStepCount(0);
    setDistanceTraveled(0);
    setEndRoute(false);
    setStartTime(null);
    setEndTime(null);
    setElapsedTime(0); // Reset elapsed time
  };

  return (
    <View style={styles.container}>
      {!start ? (
        <View style={styles.container2}>
          <Image
            style={styles.image2}
            source={require('./assets/direction-vector-47738775.jpg')}
          />
          <TouchableOpacity onPress={startMethod} style={styles.button}>
            <Text style={styles.text}>START</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.container}>
          <MapView
            showsUserLocation={true}
            followsUserLocation={true}
            userLocationUpdateInterval={1000}
            style={styles.map}
            initialRegion={{
              latitude: coordinate.latitude,
              longitude: coordinate.longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
            onUserLocationChange={(e) => {
              if (!endRoute) {
                if (count > 0) {
                  add();
                }
                setCoord(e.nativeEvent.coordinate);
                setCount(count + 1);
                if (!bool) {
                  setCoord2(e.nativeEvent.coordinate);
                  setBool(true);
                }
              }
            }}>
            <Marker coordinate={coordinate2} />
            <Polyline coordinates={list} strokeColor="#000" strokeWidth={6} />
            {endRoute && <Marker coordinate={coordinate} pinColor="green" />}
          </MapView>
          {!endRoute && (
            <TouchableOpacity onPress={endRouteMethod} style={styles.endButton}>
              <Text style={styles.endButtonText}>End Route</Text>
            </TouchableOpacity>
          )}
          <Text style={styles.distanceText}>
            Distance Traveled: {distanceTraveled.toFixed(2)} feet
          </Text>
          <Text style={styles.elapsedTimeText}>
            Elapsed Time: {elapsedTime} seconds
          </Text>
          {endRoute && (
            <Text style={styles.avgMileTimeText}>
              Avg. Mile Time: {calculateAvgMileTime() || 'No Distance'} minutes
            </Text>
          )}
          {endRoute && (
            <TouchableOpacity onPress={restart} style={styles.restartButton}>
              <Text style={styles.restartButtonText}>Restart</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eff2f1',
  },
  container2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  map: {
    flex: 1,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  text: {
    color: 'white',
    fontSize: 20,
  },
  endButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: 'red',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  endButtonText: {
    color: 'white',
    fontSize: 16,
  },
  distanceText: {
    position: 'absolute',
    bottom: 100,
    left: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 10,
    borderRadius: 5,
  },
  elapsedTimeText: {
    position: 'absolute',
    bottom: 140,
    left: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 10,
    borderRadius: 5,
  },
  avgMileTimeText: {
    position: 'absolute',
    bottom: 60,
    left: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 10,
    borderRadius: 5,
  },
  restartButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: 'green',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  restartButtonText: {
    color: 'white',
    fontSize: 16,
  },
  image2: {
    resizeMode: 'contain',
    height: '70%',
    width: '100%',
  },
});
